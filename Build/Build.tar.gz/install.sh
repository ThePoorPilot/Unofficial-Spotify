#!/bin/bash
./build.sh
echo "Installing..."
sudo dpkg -i ./spotify-unofficial_latest_amd64.deb
